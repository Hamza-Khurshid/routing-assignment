import React, { Component } from 'react'

export default class News extends Component {
    render() {
        return (
            <div>
                <h1>News</h1>
            </div>
        )
    }
};