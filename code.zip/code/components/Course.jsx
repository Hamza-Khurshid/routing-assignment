import React, { Component } from 'react'

export default class Course extends Component {
    render() {
        return (
            <div>
                <h1>Course</h1>
            </div>
        )
    }
}
